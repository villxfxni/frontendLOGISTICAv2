import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import InicioSesion from "./Components/InicioSesion.jsx";
import Registro from "./Components/Registro.jsx";
import useTokenExpirationCheck from "./Components/useTokenExpirationCheck";
import HolaMundo from "./Components/HolaMundo.jsx";
import Donaciones from "./Components/Donaciones.jsx";
import FormularioSolicitud from "./Components/FormularioSolicitud.jsx";
import Seguimiento from "./Components/Seguimiento.jsx";
import ListarSolicitudes from "./Components/ListarSolicitudes.jsx";
function TokenExpirationCheck() {
    useTokenExpirationCheck();
    return null;
}

function App() {
    return (
        <Router>
            <TokenExpirationCheck />
            <Routes>
                <Route path="/login" element={<InicioSesion/>}/>
                <Route path="/registrate" element={<Registro/>}/>
                <Route path="/Donaciones" element={<Donaciones/>}/>
                <Route path="/Seguimiento" element={<Seguimiento/>}/>
                <Route path="/Solicitudes" element={<ListarSolicitudes/>}/>
                <Route path="/Solicitar" element={<FormularioSolicitud/>}/>
                <Route path="/HolaMundo" element={<HolaMundo/>}/>  {/* ARCHIVO TEMPORAL SOLO  PARA TESTEAR LOGIN*/}
            </Routes>
        </Router>
    );
}


export default App;