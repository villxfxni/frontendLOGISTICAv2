function HolaMundo(){
    return <h1 className="text-bg-light">INGRESO EXITOSO REDIRIGIENDO A LOGIN EN 10 SEGUNDOS....</h1>
}

export default HolaMundo;