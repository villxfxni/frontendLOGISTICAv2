import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

function Header() {
    return (
        <header className="shadow p-2 p-md-3 d-flex flex-column flex-md-row align-items-center justify-content-between text-black" style={{ backgroundColor: "#ffffff" }}>
            <div className="ms-md-3 col-12 col-md-auto mb-2 mb-md-0 text-center text-md-start">
                <img src="/logoMIN.png" alt="Logo" height={50} />
            </div>
            <nav className="col-12 col-md-auto d-flex flex-wrap justify-content-center justify-content-md-end">
                <Link to="/solicitar" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitar</Link>
                <Link to="/solicitudes" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitudes</Link>
                <Link to="/donaciones" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Donaciones</Link>
                <Link to="/seguimiento" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Seguimiento</Link>
            </nav>
            <div className="me-md-3 col-12 col-md-auto mt-2 mt-md-0 text-center">
                {/* user dropdown */}
            </div>
        </header>
    );
}

const RequestCard = ({ request }) => {
    return (
        <div className="card shadow-sm p-3 mb-3 text-black" style={{ borderRadius: "12px", flexShrink: 0, height: "100%" }}>
            <div className="card-body d-flex flex-column text-start">
                <h5 className="card-title fw-bold mb-3 mb-md-4">SOLICITUD {request.id}</h5>
                <p className="card-text mb-1"><strong>Solicitante:</strong> {request.encargado}</p>
                <p className="card-text mb-1"><strong>Dirección:</strong> {request.direccion}</p>
                <p className="card-text mb-1"><strong>Fecha:</strong> {request.fechaSolicitud}</p>

                <div className="mt-2">
                    <h6 className="fw-bold">Productos:</h6>
                    <ul className="list-unstyled">
                        {request.listadoProductos.join(', ')}
                    </ul>
                </div>

                <div className="d-flex justify-content-end gap-2 gap-md-3 mt-3">
                    <button className="btn btn-outline-danger pt-1 pb-1" style={{ fontSize: "smaller" }}>Rechazar</button>
                    <button className="btn btn-outline-dark pt-1 pb-1" style={{ fontSize: "smaller" }}>Aceptar</button>
                </div>
            </div>
        </div>
    );
};

const Solicitudes = () => {
    const [dateFilter, setDateFilter] = useState("Recientes");
    const mockRequests = [
        {
            id: "SOL001",
            encargado: "María González",
            direccion: "Calle Principal #123, Ciudad",
            listadoProductos: ["Arroz 5kg", "Frijoles 2kg", "Aceite 1L"],
            fechaSolicitud: "2023-05-15"
        },
        {
            id: "SOL002",
            encargado: "Carlos Mendoza",
            direccion: "Avenida Central #456, Colonia",
            listadoProductos: ["Leche en polvo", "Atún 200g", "Harina 1kg"],
            fechaSolicitud: "2023-05-10"
        },
        {
            id: "SOL003",
            encargado: "Ana López",
            direccion: "Boulevard Norte #789, Pueblo",
            listadoProductos: ["Azúcar 2kg", "Café 500g", "Galletas"],
            fechaSolicitud: "2023-05-18"
        },
        {
            id: "SOL004",
            encargado: "Pedro Ramírez",
            direccion: "Callejón Sur #321, Villa",
            listadoProductos: ["Pasta 1kg", "Sardinas 200g", "Sal 500g"],
            fechaSolicitud: "2023-05-05"
        },
        {
            id: "SOL005",
            encargado: "Luisa Fernández",
            direccion: "Pasaje Este #654, Barrio",
            listadoProductos: ["Arroz 10kg", "Frijoles 5kg", "Aceite 2L", "Azúcar 5kg"],
            fechaSolicitud: "2023-05-20"
        },
        {
            id: "SOL006",
            encargado: "Jorge Silva",
            direccion: "Calle Oeste #987, Aldea",
            listadoProductos: ["Leche en polvo", "Cereal", "Mantequilla"],
            fechaSolicitud: "2023-05-12"
        },
    ];

    const filteredRequests = mockRequests.sort((a, b) => {
        if (dateFilter === "Recientes") {
            return new Date(b.fechaSolicitud) - new Date(a.fechaSolicitud);
        } else if (dateFilter === "Antiguas") {
            return new Date(a.fechaSolicitud) - new Date(b.fechaSolicitud);
        }
        return 0;
    });

    return (
        <div style={{
            minHeight: '100vh',
            width: '100vw',
            display: 'flex',
            flexDirection: 'column',
            overflowX: 'hidden',
            backgroundColor: '#e0e0d1',
        }}>
            <Header />
            <div className="flex-grow-1 m-1">
                <div className="container-fluid h-100 d-flex justify-content-center align-items-center">
                    <div className="w-100 w-md-75 h-100 p-2 m-1 m-md-3 rounded">
                        <div className="bg-white rounded pt-3 pb-3 ms-1 ms-md-3 me-1 me-md-3">
                            <h3 className="text-center mt-2 mb-0 display-6 text-black" style={{ fontWeight: "bold" }}>Solicitudes</h3>

                            {/* Filtro por fecha */}
                            <div className="d-flex flex-wrap justify-content-center gap-2 mt-3 mt-md-4 text-black">
                                {["Recientes", "Antiguas"].map(option => (
                                    <button
                                        key={option}
                                        className={`btn ${dateFilter === option ? "btn-dark" : "btn-outline-secondary"}`}
                                        onClick={() => setDateFilter(option)}
                                        style={{ whiteSpace: "nowrap" }}
                                    >
                                        {option}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="row g-3 justify-content-center p-1 p-md-3">
                            {filteredRequests.map((request, index) => (
                                <div key={index} className="col-12 col-md-6 col-lg-4">
                                    <RequestCard request={request} />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
export default Solicitudes

