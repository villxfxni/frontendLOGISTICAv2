import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link, useNavigate} from 'react-router-dom';
import './Style.css';


function Header() {
    return (
        <header className="shadow p-2 p-md-3 d-flex flex-column flex-md-row align-items-center justify-content-between text-black" style={{ backgroundColor: "#ffffff" }}>
            <div className="ms-md-3 col-12 col-md-auto mb-2 mb-md-0 text-center text-md-start">
                <img src="/logoMIN.png" alt="Logo" height={50} />
            </div>
            <nav className="col-12 col-md-auto d-flex flex-wrap justify-content-center justify-content-md-end">
                <Link to="/solicitar" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitar</Link>
                <Link to="/solicitudes" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitudes</Link>
                <Link to="/donaciones" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Donaciones</Link>
                <Link to="/seguimiento" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Seguimiento</Link>
            </nav>
            <div className="me-md-3 col-12 col-md-auto mt-2 mt-md-0 text-center">
                {/* user dropdown */}
            </div>
        </header>
    );
}
function FormularioSolicitud() {
    const navigate = useNavigate();

    const initialValues = {
        nombre: '',
        apellido: '',
        correoElectronico: '',
        cedulaIdentidad: '',
        contrasena: ''
    };

    const validationSchema = Yup.object({
        nombre: Yup.string()
            .required('El nombre es obligatorio'),
        apellido: Yup.string()
            .required('El apellido es obligatorio'),
        cedulaIdentidad: Yup.string()
            .required('El C.I. es obligatorio'),
        correoElectronico: Yup.string()
            .required('El correo electrónico es obligatorio')
            .email('Verifica el formato de correo electronico'),
        contrasena: Yup.string()
            .required('La contraseña es obligatoria')
    });

    return (
        <div style={{
            minHeight: '100vh',
            width: '100vw',
            display: 'flex',
            flexDirection: 'column',
            overflowX: 'hidden',
            backgroundColor: '#e0e0d1',
        }}>
            <Header/>
            <div className="container-fluid d-flex flex-column align-items-center h-100 w-100 mb-3 py-2"
                 style={{backgroundColor: '#e0e0d1'}}>
                <div className="row w-100 p-1 mt-2 mt-md-4 shadow rounded"
                     style={{maxWidth: '95%', background: '#ffffff'}}>
                    <div className="d-flex flex-column justify-content-start align-items-center">
                        <Formik
                            initialValues={initialValues}
                            validationSchema={validationSchema}
                            onSubmit={null}
                        >
                            {({isSubmitting}) => (
                                <Form style={{fontSize: 'medium'}} className="w-100">
                                    <div className="row">
                                        <div className="col-md-6 pe-md-5 ps-md-5 px-3">
                                            <h3 className="text-center mt-3 mb-4 display-6"
                                                style={{fontSize: 'xx-large', fontWeight:"normal"}}>Solicitar
                                                Insumos</h3>
                                            <div className="mb-0 mt-3 d-flex flex-column flex-md-row">
                                                <label htmlFor="cedulaidentidad" className="mt-1 me-md-3 p-0 form-label w-100">Carnet
                                                    de Indentidad (C.I.):</label>
                                                <Field type="number" name="cedulaidentidad" className="form-control m-0"
                                                       placeholder="Ej. 1234567"/>
                                            </div>
                                            <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                <ErrorMessage name="cedulaidentidad" component="div"
                                                              className="text-danger"/>
                                            </div>

                                            <div className="mb-0 mt-3 d-flex flex-column flex-md-row">
                                                <label htmlFor="comunidad" className="mt-1 me-md-3 p-0 form-label w-100">Comunidad
                                                    Solicitante:</label>
                                                <Field type="text" name="cedulaidentidad" className="form-control m-0"
                                                       placeholder="Ej. San Jose de Chiquitos"/>
                                            </div>
                                            <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                <ErrorMessage name="comunidad" component="div" className="text-danger"/>
                                            </div>
                                            <div className="mb-0 mt-3 d-flex flex-column flex-md-row">
                                                <label htmlFor="fechaInicio"
                                                       className="mt-1 me-md-3 p-0 form-label">Inicio del Incendio:</label>
                                                <Field type="date" name="fechaInicio" className="form-control m-0"
                                                       placeholder=""/>
                                            </div>
                                            <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                <ErrorMessage name="fechaInicio" component="div" className="text-danger"/>
                                            </div>
                                            <div className="mb-0 mt-3">
                                                <label htmlFor="productos"
                                                       className="mt-1 me-3 p-0 form-label">Insumos Necesarios:</label>
                                                <Field component="textarea" rows="5" name="productos"
                                                       className="form-control m-0"
                                                       placeholder="Ingrese la lista de productos y la cantidad separados por comas ( , )"/>
                                            </div>
                                            <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                <ErrorMessage name="celular" component="div" className="text-danger"/>
                                            </div>

                                            <div className="d-flex justify-content-center">
                                                <button type="submit" className="btn w-100 w-md-50 mt-3 mb-3"
                                                        style={{backgroundColor: '#ffd833', color: 'black'}}
                                                        disabled={isSubmitting}>
                                                    {isSubmitting ? 'Enviando...' : 'Enviar Solicitud'}
                                                </button>
                                            </div>
                                        </div>
                                        <div className="col-md-6 pe-md-5 ps-md-5 px-3 mt-3 mt-md-5">
                                            <div className="rounded p-2" style={{backgroundColor: 'rgba(255,216,51,0.67)'}}>
                                                <h3 className="mt-2 text-black-100" style={{fontSize: 'large'}}>Datos para
                                                    la Entrega</h3>
                                                <div className="mb-0 mt-2 d-flex flex-column flex-md-row">
                                                    <label htmlFor="direccion"
                                                           className="mt-1 me-md-3 p-0 form-label">Dirección:</label>
                                                    <Field type="text" name="direccion" className="form-control m-0"
                                                           placeholder="Ej. Calle 123, Av. Nuevo Dia"/>
                                                </div>
                                                <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                    <ErrorMessage name="direccion" component="div" className="text-danger"/>
                                                </div>
                                                <div className="mb-0 mt-2 d-flex flex-column flex-md-row">
                                                    <label htmlFor="provincia"
                                                           className="mt-1 me-md-3 p-0 form-label">Provincia:</label>
                                                    <Field type="text" name="provincia" className="form-control m-0"
                                                           placeholder="Ej. San Jose de Chiquitos"/>
                                                </div>
                                                <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                    <ErrorMessage name="provincia" component="div" className="text-danger"/>
                                                </div>

                                                <div className="mb-0 mt-2 d-flex flex-column flex-md-row">
                                                    <label htmlFor="celular"
                                                           className="mt-1 me-md-3 p-0 form-label">Nro de Celular:</label>
                                                    <Field type="number" name="celular" className="form-control m-0"
                                                           placeholder="Ej. +591 77312305"/>
                                                </div>
                                                <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                                    <ErrorMessage name="celular" component="div" className="text-danger"/>
                                                </div>
                                            </div>
                                            <div className="mt-2 mb-3 text-center">
                                                <p className="text-center"
                                                   style={{color: 'grey', fontSize:"smaller"}}>Al realizar esta solicitud eres responsable de
                                                    recibirla en el lugar</p>
                                                <img src="/chiquitos.jpg" className="rounded img-fluid" style={{
                                                    objectFit: 'cover',
                                                    objectPosition: 'center',
                                                    height: '200px',
                                                    maxWidth: '100%',
                                                }}/>
                                            </div>
                                        </div>
                                    </div>
                                </Form>
                            )}
                        </Formik>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default FormularioSolicitud;