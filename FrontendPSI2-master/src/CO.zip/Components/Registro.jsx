import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link, useNavigate} from 'react-router-dom';
import {registerUser} from "../Services/authService.js";


function Header() {
    return (
        <header className="shadow p-2 p-md-3 d-flex flex-column flex-md-row align-items-center justify-content-between text-black" style={{ backgroundColor: "#ffffff" }}>
            <div className="ms-md-3 col-12 col-md-auto mb-2 mb-md-0 text-center text-md-start">
                <img src="/logoMIN.png" alt="Logo" height={50} />
            </div>
            <nav className="col-12 col-md-auto d-flex flex-wrap justify-content-center justify-content-md-end">
                <Link to="/solicitar" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitar</Link>
                <Link to="/solicitudes" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitudes</Link>
                <Link to="/donaciones" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Donaciones</Link>
                <Link to="/seguimiento" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Seguimiento</Link>
            </nav>
            <div className="me-md-3 col-12 col-md-auto mt-2 mt-md-0 text-center">
                {/* user dropdown */}
            </div>
        </header>
    );
}

function Registro() {
    const navigate = useNavigate();

    const initialValues = {
        nombre: '',
        apellido: '',
        correoElectronico: '',
        cedulaIdentidad: '',
        contrasena: ''
    };

    const validationSchema = Yup.object({
        nombre: Yup.string()
            .required('El nombre es obligatorio')
        ,
        apellido: Yup.string()
            .required('El apellido es obligatorio'),
        cedulaIdentidad: Yup.string()
            .required('El C.I. es obligatorio'),
        correoElectronico: Yup.string()
            .required('El correo electrónico es obligatorio')
            .email('Verifica el formato de correo electronico')
        ,
        contrasena: Yup.string()
            .min(6, 'Minimo 6 caracteres')
            .required('La contraseña es obligatoria')
    });
    const handleSubmit = async (values, { setSubmitting, setErrors }) => {
        console.log('Form values:', values);

        try {
            await registerUser(values);
            alert('Registro exitoso');
            navigate('/login');
        } catch (error) {
            console.error('Error al registrar:', error);
            setErrors({ general: error.response?.data?.message || 'Error en el registro' });
        }
        setSubmitting(false);
    };

    return (
        <div>
            <Header/>
            <div className="container-fluid d-flex flex-column  align-items-center vh-100 w-100 " style={{backgroundColor:'#e0e0d1'}} >
                <div className="row w-100 h-75 p-1 mt-4 shadow rounded" style={{maxWidth: '85%', background: '#ffffff'}}>
                    <div className="col-md-6 d-flex flex-column justify-content-start align-items-center">
                        <h3 className="text-center mt-2 display-6" style={{fontSize: 'xx-large'}}>Crear una Cuenta</h3>
                        <Formik
                            initialValues={initialValues}
                            validationSchema={validationSchema}
                            onSubmit={handleSubmit}
                        >
                            {({isSubmitting}) => (
                                <Form style={{fontSize: 'medium'}}>
                                    <div className="mb-0 mt-2 d-flex flex-row">
                                        <label htmlFor="nombre" className="form-label col-md-6">Nombre</label>
                                        <label htmlFor="apellido" className="form-label col-md-6 ms-2">Apellido</label>
                                    </div>
                                    <div className="mb-0 mt-0 d-flex flex-row">
                                        <Field type="text" name="nombre" className="form-control me-3"
                                               placeholder="Ej. Maria"/>
                                        <Field type="text" name="apellido" className="form-control"
                                               placeholder="Ej. Rodriguez"/>
                                    </div>
                                    <div className="mb-2 mt-0" style={{fontSize: 'smaller'}}>
                                        <ErrorMessage name="nombre" component="div" className="text-danger"/>
                                        <ErrorMessage name="apellido" component="div" className="text-danger"/>
                                    </div>
                                    <div className="mb-2 mt-2">
                                        <label htmlFor="cedulaIdentidad" className="form-label">C.I.</label>
                                        <Field type="number" name="cedulaIdentidad" className="form-control"
                                               placeholder="Ej. 1234567"/>
                                        <ErrorMessage name="cedulaIdentidad" component="div" className="text-danger"
                                                      style={{fontSize: 'smaller'}}/>
                                    </div>
                                    <div className="mb-2 mt-2">
                                        <label htmlFor="correoElectronico" className="form-label">Correo Electrónico</label>
                                        <Field type="email" name="correoElectronico" className="form-control"
                                               placeholder="Ej. nombre@email.com"/>
                                        <ErrorMessage name="correoElectronico" component="div" className="text-danger"
                                                      style={{fontSize: 'smaller'}}/>
                                    </div>
                                    <div className="mb-2 mt-2">
                                        <label htmlFor="contrasena" className="form-label">Contraseña</label>
                                        <Field type="password" name="contrasena" className="form-control" placeholder=""/>
                                        <ErrorMessage name="contrasena" component="div" className="text-danger"
                                                      style={{fontSize: 'smaller'}}/>
                                    </div>
                                    <div className="mb-2 mt-2 visually-hidden" id="passConf">
                                        <label htmlFor="passwordConf" className="form-label">Confirmar
                                            Contraseña</label>
                                        <Field type="password" name="passwordConf" className="form-control"
                                               placeholder=""/>
                                        <ErrorMessage name="passwordConf" component="div" className="text-danger"
                                                      style={{fontSize: 'smaller'}}/>
                                    </div>
                                    <button type="submit" className="btn w-100 mt-2"
                                            style={{backgroundColor: '#ffd833', color: 'black'}}
                                            disabled={isSubmitting}>
                                        {isSubmitting ? 'Registrando...' : 'Registrarse'}
                                    </button>
                                    <p className="mt-3 mb-3 text-center ms-5 me-5"
                                       style={{color: 'grey', fontSize: 'smaller'}}>
                                        ¿Ya tienes una cuenta? <Link to="/login"
                                                                     style={{color: 'black'}}>Ingresar</Link>.
                                    </p>
                                </Form>
                            )}
                        </Formik>
                    </div>
                    <div
                        className="col-md-6 ms-0 mt-1 mb-2 d-flex justify-content-center align-items-center border-start">
                        <div className="text-center">
                            <img src="/logoNOBG.png" alt="App Logo" className="img-fluid rounded-4"
                                 style={{maxWidth: '80%'}}/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Registro;