import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import {Link, useNavigate} from 'react-router-dom';
import {loginUser, saveToken} from '../services/authService';
import 'bootstrap/dist/css/bootstrap.min.css';


function Header() {
    return (
        <header className="shadow p-2 p-md-3 d-flex flex-column flex-md-row align-items-center justify-content-between text-black" style={{ backgroundColor: "#ffffff" }}>
            <div className="ms-md-3 col-12 col-md-auto mb-2 mb-md-0 text-center text-md-start">
                <img src="/logoMIN.png" alt="Logo" height={50} />
            </div>
            <nav className="col-12 col-md-auto d-flex flex-wrap justify-content-center justify-content-md-end">
                <Link to="/solicitar" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitar</Link>
                <Link to="/solicitudes" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitudes</Link>
                <Link to="/donaciones" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Donaciones</Link>
                <Link to="/seguimiento" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Seguimiento</Link>
            </nav>
            <div className="me-md-3 col-12 col-md-auto mt-2 mt-md-0 text-center">
                {/* user dropdown */}
            </div>
        </header>
    );
}
function InicioSesion() {
    const navigate = useNavigate();

    const initialValues = {
        cedulaIdentidad: '',
        contrasena: ''
    };

    const validationSchema = Yup.object({
        cedulaIdentidad: Yup.string().required('El C.I. es obligatorio'),
        contrasena: Yup.string().required('La contraseña es obligatoria')
    });

    const handleSubmit = async (values, { setSubmitting, setErrors }) => {
        try {
            console.log('Form values:', values);
            const response = await loginUser(values);
            console.log('Login successful:', response);

            const token = response.token;
            const expiration = response.expiration;
            saveToken(token, expiration);

            navigate('/Donaciones');
        } catch (error) {
            setErrors({ contrasena: 'C.I. o contraseña incorrectos' });
        }
        setSubmitting(false);
    };

    return (
        <div >
            <Header />
            <div className="container-fluid d-flex flex-column  align-items-center vh-100 w-100 "  style={{ backgroundColor: '#e0e0d1' }} >
                <div className="row w-100 h-75 p-1 mt-4 shadow rounded" style={{ maxWidth: '85%', background: '#ffffff' }}>
                    <div className="col-md-6 mt-2 mb-2 ms-0 d-flex justify-content-center align-items-center border-end">
                        <div className="text-center">
                            <img src="/logoNOBG.png" alt="App Logo" className="img-fluid rounded-4" style={{ maxWidth: '80%' }} />
                        </div>
                    </div>
                    <div className="col-md-6 d-flex flex-column justify-content-start align-items-center">
                        <h3 className="text-center mt-5 display-6">Iniciar Sesión</h3>
                        <Formik
                            initialValues={initialValues}
                            validationSchema={validationSchema}
                            onSubmit={handleSubmit}
                        >
                            {({ isSubmitting }) => (
                                <Form>
                                    <div className="mb-3 mt-4">
                                        <label htmlFor="cedulaIdentidad" className="form-label">C.I.</label>
                                        <Field type="text" name="cedulaIdentidad" className="form-control" placeholder="Ej. 1234567" />
                                        <ErrorMessage name="cedulaIdentidad" component="div" className="text-danger" />
                                    </div>
                                    <div className="mb-3 mt-4">
                                        <label htmlFor="contrasena" className="form-label">Contraseña</label>
                                        <Field type="password" name="contrasena" className="form-control" />
                                        <ErrorMessage name="contrasena" component="div" className="text-danger" />
                                    </div>
                                    <button type="submit" className="btn w-100 mt-4" style={{ backgroundColor: '#ffd833', color: 'black' }}  disabled={isSubmitting}>
                                        {isSubmitting ? 'Ingresando...' : 'Ingresar'}
                                    </button>
                                    <p className="mt-4 mb-5 text-center ms-5 me-5" style={{color:'grey', fontSize:'smaller'}}>
                                        ¿No tienes una cuenta? <Link to="/registrate" style={{color:'black'}}>Regístrate aquí</Link>
                                    </p>
                                </Form>
                            )}
                        </Formik>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default InicioSesion;