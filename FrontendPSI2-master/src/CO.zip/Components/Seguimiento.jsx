import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

function Header() {
    return (
        <header className="shadow p-2 p-md-3 d-flex flex-column flex-md-row align-items-center justify-content-between text-black" style={{backgroundColor:"#ffffff"}}>
            <div className="ms-md-3 col-12 col-md-auto mb-2 mb-md-0 text-center text-md-start">
                <img src="/logoMIN.png" alt="Logo" height={50}/>
            </div>
            <nav className="col-12 col-md-auto d-flex flex-wrap justify-content-center justify-content-md-end">
                <Link to="/Solicitar" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitar</Link>
                <Link to="/Donaciones" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Donaciones</Link>
                <Link to="/Seguimiento" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Seguimiento</Link>
            </nav>
            <div className="me-md-3 col-12 col-md-auto mt-2 mt-md-0 text-center">
                {/* user dropdown */}
            </div>
        </header>
    );
}

const SeguimientoCard = ({ seguimiento }) => {
    return (
        <div className="card shadow-sm p-1 mb-4 text-black w-100" style={{borderRadius: "12px", flexShrink: 0}}>
            <div className="card-body d-flex flex-column flex-md-row text-start w-100 gap-3 gap-md-5">
                {seguimiento.imagen ? (
                    <img src={seguimiento.imagen} className="card-img-top" alt="Donación"
                         style={{borderRadius: "8px", width: "100%", maxWidth: "200px", height: "200px", objectFit: "cover"}}/>
                ) : (
                    <img src="/truck.png" className="card-img-top" alt="Truck"
                         style={{borderRadius: "8px", width: "100%", maxWidth: "200px", height: "200px", objectFit: "cover"}}/>
                )}
                <div className="col flex-column text-start">
                    <h5 className="card-title fw-bold">DONACIÓN {seguimiento.idDonacion}</h5>
                    <p className="card-text"><strong>Encargado:</strong> {seguimiento.encargado}</p>
                    <p className="card-text"><strong>Origen:</strong> {seguimiento.origen}</p>
                    <p className="card-text"><strong>Destino:</strong> {seguimiento.destino}</p>
                    <p className="card-text"><strong>Fecha de Actualización:</strong> {seguimiento.fechaActualizacion}</p>
                </div>
                <div className="d-flex align-items-center">
                    <p className="badge mb-0 pe-3 pt-2" style={{
                        backgroundColor: seguimiento.estado === "Pendiente" ? "#8a8a8a" : "#ff9500",
                        display: 'inline-block',
                        width: '12px',
                        height: '24px',
                        borderRadius: '50%',
                    }}></p>
                </div>
            </div>
        </div>
    );
};

const Seguimiento = () => {
    const [filter, setFilter] = useState("Todos");
    const mockSeguimiento = [
        {idDonacion: "ABC123", estado:"Pendiente", encargado: "Juan Pinto", origen:'Almacen 1', destino: 'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
        {idDonacion: "DCF345", estado:"En Camino", encargado: "Juan Pinto", origen: 'Almacen 2', destino:'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
        {idDonacion: "SJDC234", estado:"Pendiente", encargado: "Juan Pinto", origen: 'Almacen 1', destino:'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
        {idDonacion: "SCZ2336", estado:"En Camino", encargado: "Juan Pinto", origen: 'Almacen 1', destino:'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
        {idDonacion: "SCZ2336", estado:"En Camino", encargado: "Juan Pinto", origen: 'Almacen 2', destino:'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
        {idDonacion: "SCZ2336", estado:"Pendiente", encargado: "Juan Pinto", origen: 'Almacen 2', destino:'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
        {idDonacion: "SCZ2336", estado:"En Camino", encargado: "Juan Pinto", origen: 'Almacen 1', destino:'ubicacion', fechaActualizacion:'01-01-2025', imagenEvidencia:''},
    ];

    return (
        <div style={{
            minHeight: '100vh',
            width: '100vw',
            display: 'flex',
            flexDirection: 'column',
            overflowX: 'hidden',
            backgroundColor: '#e0e0d1',
        }}>
            <Header/>
            <div className="flex-grow-1 m-1">
                <div className="container-fluid h-100 d-flex col justify-content-center align-items-center">
                    <div className="w-100 w-md-75 h-100 p-2 m-1 m-md-3 rounded">
                        <div className="rounded pt-3 pb-3 ms-1 ms-md-3 me-1 me-md-3">
                            <h3 className="ps-1 ps-md-3 mt-2 mb-0 display-6 text-black" style={{fontWeight: "bold"}}>Seguimiento
                                de las Donaciones</h3>
                            <div className="d-flex flex-row mt-2">
                                <p className="ms-1 ms-md-3 me-1 me-md-3">
                                    <span style={{
                                        display: 'inline-block',
                                        width: '15px',
                                        height: '15px',
                                        borderRadius: '50%',
                                        marginTop: "8px",
                                        backgroundColor: '#8a8a8a'
                                    }}>
                                    </span> Pendiente
                                </p>
                                <p>
                                    <span style={{
                                        display: 'inline-block',
                                        width: '15px',
                                        height: '15px',
                                        borderRadius: '50%',
                                        marginTop: "8px",
                                        backgroundColor: '#ff9500'
                                    }}></span> En Camino
                                </p>
                            </div>
                        </div>

                        <div className="w-100 p-1 p-md-3">
                            {mockSeguimiento.map((seguimiento, index) => (
                                <div key={index} className="">
                                    <SeguimientoCard seguimiento={seguimiento}/>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Seguimiento;