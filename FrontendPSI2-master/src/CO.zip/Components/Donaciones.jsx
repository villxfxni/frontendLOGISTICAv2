import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

function Header() {
    return (
        <header className="shadow p-2 p-md-3 d-flex flex-column flex-md-row align-items-center justify-content-between text-black" style={{backgroundColor:"#ffffff"}}>
            <div className="ms-md-3 col-12 col-md-auto mb-2 mb-md-0 text-center text-md-start">
                <img src="/logoMIN.png" alt="Logo" height={50}/>
            </div>
            <nav className="col-12 col-md-auto d-flex flex-wrap justify-content-center justify-content-md-end">
                <Link to="/Solicitar" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Solicitar</Link>
                <Link to="/Donaciones" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Donaciones</Link>
                <Link to="/Seguimiento" className="mx-1 mx-md-3 my-1 text-decoration-none text-dark">Seguimiento</Link>
            </nav>
            <div className="me-md-3 col-12 col-md-auto mt-2 mt-md-0 text-center">
                {/* user dropdown */}
            </div>
        </header>
    );
}

const DonationCard = ({ donation }) => {
    const estado = donation.fechaEntrega ? "Entregado" : "No Entregado";

    return (
        <div className="card shadow-sm p-3 mb-4 text-black" style={{borderRadius: "12px", flexShrink: 0, height: "100%"}}>
            <p className="badge mb-0" style={{
                backgroundColor: estado === "Entregado" ? "#0b6730" : "#cc0000",
                color: "#ffffff",
                fontSize: "10px",
                fontWeight: "normal",
                width: 'fit-content'
            }}>{estado}
            </p>
            <div className="card-body d-flex flex-column text-start">
                <h5 className="card-title fw-bold">DONACIÓN {donation.id}</h5>
                <p className="card-text">Encargado: <strong>{donation.encargado}</strong></p>
                <button className="btn btn-outline-dark pt-1 pb-1 align-self-start" style={{fontSize:"smaller"}}>Actualizar</button>

                {donation.imagen ? (
                    <img src={donation.imagen} className="card-img-top mt-2 img-fluid" alt="Donación" style={{borderRadius: "8px"}}/>
                ) : (
                    <img src="/truck.png" className="card-img-top mt-2 img-fluid" alt="Truck"
                         style={{borderRadius: "8px", maxWidth: "150px", maxHeight: "150px", alignSelf: "center"}}/>
                )}
            </div>
        </div>
    );
};

const Donaciones = () => {
    const [filter, setFilter] = useState("Todos");
    const mockDonations = [
        {id: "ABC123", encargado: "Juan Pinto", imagen: null, fechaEntrega:null},
        {id: "DCF345", encargado: "Juan Pinto", imagen: null, fechaEntrega: '2025-27-03'},
        {id: "SJDC234", encargado: "Juan Pinto", imagen: null, fechaEntrega:null},
        {id: "SCZ2336", encargado: "Juan Pinto", imagen: null, fechaEntrega:'2025-22-03'},
        {id: "SCZ2336", encargado: "Juan Pinto", imagen: null, fechaEntrega:'2025-15-05'},
        {id: "SCZ2336", encargado: "Juan Pinto", imagen: null, fechaEntrega:null},
        {id: "SCZ2336", encargado: "Juan Pinto", imagen: null, fechaEntrega:null},
    ];

    const filteredDonations = mockDonations.filter((donation) => {
        const estado = donation.fechaEntrega ? "Entregado" : "No Entregado";
        return filter === "Todos" || estado === filter;
    });

    return (
        <div style={{
            minHeight: '100vh',
            width: '100vw',
            display: 'flex',
            flexDirection: 'column',
            overflowX: 'hidden',
            backgroundColor: '#e0e0d1',
        }}>
            <Header/>
            <div className="flex-grow-1 m-1">
                <div className="container-fluid h-100 d-flex col justify-content-center align-items-center">
                    <div className="w-100 w-md-75 h-100 p-2 m-1 m-md-3 rounded">
                        <div className="bg-white rounded pt-3 pb-3 ms-1 ms-md-3 me-1 me-md-3">
                            <h3 className="text-center mt-2 mb-0 display-6 text-black" style={{fontWeight:"bold"}}>Donaciones</h3>
                            <div className="d-flex flex-wrap justify-content-center gap-2 mt-3 mt-md-4 text-black">
                                {["Todos", "Entregado", "No Entregado"].map(category => (
                                    <button
                                        key={category}
                                        className={`btn ${filter === category ? "btn-dark" : "btn-outline-secondary"}`}
                                        onClick={() => setFilter(category)}
                                        style={{whiteSpace: "nowrap"}}
                                    >
                                        {category}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="row g-4 justify-content-center p-1 p-md-3">
                            {filteredDonations.map((donation, index) => (
                                <div key={index} className="col-12 col-sm-6 col-md-4 col-lg-3">
                                    <DonationCard donation={donation}/>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Donaciones;